# NetHunter Kernel — Redmi 9A (dandelion) — Android 10
Поддержка HID gadget и драйверов для популярных Wi-Fi адаптеров.

## Прошивка ядра
1. Загрузите архив `kernel-nethunter deepcomon (dandelion).zip` в телефон.
2. Зайдите в TWRP → Backup → сохраните раздел Boot.
3. В TWRP → Install → выберите архив ядра → свайп для прошивки.
4. Если используете Magisk — прошейте его сразу после ядра.
5. Перезагрузите в систему.

## Проверка HID
```bash
ls /sys/class/udc
```
Если виден контроллер (например, `musb-hdrc`) — HID работает.

## Проверка Wi-Fi атак
Подключите поддерживаемый адаптер через OTG:
```bash
ifconfig
airmon-ng
```

## Откат ядра
1. Зайдите в TWRP → Restore.
2. Выберите бэкап Boot.
3. Перезагрузитесь.
