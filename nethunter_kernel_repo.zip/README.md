# Nethunter Kernel Builder for Redmi 9A (dandelion)

## Как пользоваться:
1. Загрузите файл `nethunter_pack.zip` в раздел **Releases** этого репозитория.
2. Убедитесь, что в workflow (`.github/workflows/build.yml`) указан правильный URL на ваш архив.
3. Запустите сборку через вкладку **Actions** -> **Build Kernel** -> **Run workflow**.

После окончания сборки готовый `.zip` появится в артефактах сборки.
